AI SMART UTILITY — ANDROID PROJECT v3.0
=========================================

Included tools
- AI Assistant, AI Writer, Smart Translator, CV Maker, Social Caption Maker
- Image Compressor — local processing, saves the output to Downloads/AI Smart Utility
- Image to Text (OCR) — downloads Tesseract.js and English OCR data from the internet
- Voice to Text — depends on Android WebView speech-recognition support
- Image to PDF — uses PDF-lib online and saves the PDF to Downloads/AI Smart Utility
- Text to Speech — uses voices available on the device
- Prompt Builder
- QR Code Maker — online QR service; PNG download supported
- AI Background Remover — free online MediaPipe selfie segmentation, designed for people/portrait photos.
  It is not a general object/product background remover. First use downloads the AI script/model and needs internet.

FILE SAVING FIX
The Android WebView now has a native JavaScript bridge. Compressed images, generated PDFs,
QR PNGs and background-removed PNGs are written through Android MediaStore into:
Downloads/AI Smart Utility
(Android 10+). On older Android versions, files are stored in the app-specific external
Downloads folder.

IMPORTANT LIMITATIONS
1. This is Android Studio source code, not a compiled APK.
2. AI Assistant, Writer, Translator, CV and Caption generation need an OpenAI-compatible
   endpoint, API key and model. API use may cost money. No AI API key is bundled.
3. Do not publish a private API key in a public app. A secure production release should use
   a backend proxy.
4. OCR, PDF generation, QR generation and background removal require internet to load
   external libraries/services. QR content is sent to the QR service.
5. Background removal works best on a single person/selfie; results vary by photo.
6. Voice recognition depends on WebView/device support and may not work on every phone.
7. No ads, payments, subscriptions, account system, or guaranteed earning feature is included.

BUILD
- Open this project folder in Android Studio on a computer, sync Gradle, then Build > Build APK.
- Or upload the project contents to a GitHub repository with the included workflow and run
  Actions. The workflow runs `gradle assembleDebug` and uploads the APK artifact.

The project uses Android Gradle Plugin 8.6.1, Gradle 8.7, compile SDK 35 and Java 17.
