AI SMART UTILITY — AI EDITION v2.0
=================================

WHAT'S INCLUDED
- AI Assistant, AI Writer, Smart Translator, CV Maker, Social Caption Maker.
- Image compressor (local browser processing).
- Image-to-text OCR (loads Tesseract.js from the internet).
- Voice-to-text (browser/device speech recognition support required).
- Image-to-PDF (loads PDF-lib from the internet).
- Text-to-speech (device/browser voices).
- Prompt Builder and QR Code Maker.

IMPORTANT LIMITATIONS
1. This ZIP is Android Studio source code, NOT a compiled APK.
2. Real AI Assistant/Writer/Translator/CV/Caption generation requires an OpenAI-compatible provider endpoint, API key and model. You must supply these in Settings. API usage may cost money; free quotas and availability vary.
3. Entered API key is held only in page memory for the current session, not saved. A client-side API key can still be exposed to someone who can inspect the running app. Do not use a valuable/private production key in a public app. A secure public release should use a backend proxy.
4. OCR and Image-to-PDF download their libraries from the internet. QR generation uses an online QR service. Speech features depend on Android/browser support.
5. Image compression is local; selected image is not uploaded by this tool.
6. No ads, payments, login, cloud storage or guaranteed income features are included.

OPEN THE WEB APP
Extract the ZIP and open app/src/main/assets/index.html in Chrome to test the interface.
Some Android file managers may restrict local file features; use a local preview server if needed.

BUILD APK
Open this project folder in Android Studio on a computer, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
This project uses Android Gradle Plugin 8.6.1 and compile SDK 35.
